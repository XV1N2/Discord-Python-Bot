import discord
from discord.ext import commands

client = commands.Bot(command_prefix="!",help_command=None)

@client.event
async def on_ready():
    print(f'Bot Logged In As {client.user}'.format(client))

#command

@client.command(name='help')
async def help(ctx):
    embed = discord.Embed(
        title = 'Help',
        description = 'Showing All Command Bot',
        color = discord.Color.blue()
    )
    embed.add_field(name='!random',value='Give You Random Number')
    embed.add_field(name='!anywhere',value='This Command Can Be Use In Anywhere')
    embed.add_field(name='Soon',value='More Command Soon')
    await ctx.send (embed=embed)

client.run("Your Token")    