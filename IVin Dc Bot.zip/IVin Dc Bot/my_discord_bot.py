import discord
from discord import Game
import asyncio
from discord.ext import commands
from discord.ext.commands import Bot
from discord.ext.commands import has_permissions
from codeop import compile_command
from urllib import response
from click import pass_context
import random
import requests


token = "Your Bot Token"

client = discord.Client()

@client.event
async def on_ready():
    print(f'Bot Logged In As {client.user}'.format(client))

@client.event
async def on_ready():
       await client.change_presence(status=discord.Status.idle, activity=discord.Game('Prefix | !'))

@client.event
async def on_message(message):
    username = str(message.author).split('#')[0]
    client_message = str(message.content)
    channel = str(message.channel.name)
    print(f'{username}: {client_message} ({channel})')


    if message.author == client.user:
        return

    if message.channel.name == 'adu-bot,nongkrong,bot-command,general ':
            return
    if client_message.lower() == 'hi':
            await message.channel.send(f'Hello {username}:)')
            return
    elif client_message.lower() == 'babai':
            await message.channel.send(f'Babai {username}:)')
            return
    elif client_message.lower() == '!random':
            response = f'This Is Your Random Number: {random.randrange(1000000)}'
            await message.channel.send(response)
            return
    elif client_message.lower() == 'nigga':
            response = f'Shut The Fuck Up You Black Nigga {username}'
            await message.channel.send(response)
            return
    elif client_message.lower() == 'china man':
            response = f'Your Eye Sipit Udah Siang Masih Turu {username}'
            await message.channel.send(response)
            return
    if client_message.lower() == '!anywhere':
        await message.channel.send('This Command Can Use In Anywhere')
        return
    elif client_message.lower() == 'wibu':
            response = f'Hih Wibu Peler Mati Saja Kamu {username}'
            await message.channel.send(response)
            return
    elif client_message.lower() == 'si paling':
            response = f'Si Paling Si Paling Dari Pada Lu Si Kontol  {username}'
            await message.channel.send(response)
            return

client.run(token)