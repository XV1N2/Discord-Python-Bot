import discord
import random
from discord.ext import commands

client = commands.Bot(command_prefix="How ")



@client.command()
async def cool(ctx):
    await ctx.send(f"You {random.randrange(100)}% Cool")
    return
@client.command()
async def beautiful(ctx):
    await ctx.send(f"You {random.randrange(100)}% Beautiful")
    return
@client.command()
async def lesbi(ctx):
    await ctx.send(f"You {random.randrange(100)}% Lesbi")
    return
@client.command()
async def gay(ctx):
    await ctx.send(f"You {random.randrange(100)}% Gay")
    return
@client.command()
async def lonely(ctx):
    await ctx.send(f"You {random.randrange(100)}% Lonely")
    return
@client.command()
async def handsome(ctx):
    await ctx.send(f"You {random.randrange(100)}% handsome")
    return
@client.command()
async def poor(ctx):
    await ctx.send(f"You {random.randrange(100)}% Poor")
    return
@client.command()
async def rich(ctx):
    await ctx.send(f"You {random.randrange(100)}% Rich")
    return
    
client.run("Your Token")