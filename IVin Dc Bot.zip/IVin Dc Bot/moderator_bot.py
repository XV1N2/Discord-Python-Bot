from http import client
import discord


token = "Your Token"

client = discord.Client()

block_words = ["raid by", "Raid By", "RaidBy", "Nuked", "Nuke", "nuke", "Nuke By", "nuked", "nuked", "htt"]

@client.event
async def on_ready():
    print(f"Bot Logged In As {client.user}")

@client.event
async def on_message(message):
    username = str(message.author).split('#')[0]
    client_message = str(message.content)
    channel = str(message.channel.name)
    print(f'{username}: {client_message} ({channel})')

@client.event
async def on_message(message):

    if message.author != client.user:
        for text in block_words:
            if "Moderator" not in str(message.author.roles) and text in str(message.content.lower()):
                await message.delete()
                return
            await message.channel.send(f'Ouh You Owner/Mod')
            return
client.run(token)